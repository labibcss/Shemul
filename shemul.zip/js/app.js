document.addEventListener("scroll", function() {
    var sections = document.querySelectorAll("section");
    var menuItems = document.querySelectorAll(".menu li");
    
    sections.forEach(function(section, index) {
        var top = section.offsetTop;
        var height = section.clientHeight;
        if (pageYOffset >= (top - height / 3)) {
            menuItems.forEach(function(item) {
                item.classList.remove("active");
            });
            menuItems[index].classList.add("active");
        }
    });
});
window.addEventListener("scroll", function(){
    var header = document.querySelector("header");
    header.classList.toggle("sticky", window.scrollY > 0);
});
const icon_change = document.querySelector(".menu-toggle");
icon_change.addEventListener("click", () => {
    document.querySelector(".menu-toggle").classList.toggle("open");
    document.querySelector(".menu").classList.toggle("menu-open");
});
const cursor = document.querySelector('.cursor');

document.addEventListener('mousemove', e => {
    cursor.setAttribute("style", "top: "+(e.pageY - 10)+"px; left: "+(e.pageX - 10)+"px;")
})

document.addEventListener('click', () => {
    cursor.classList.add("expand");

    setTimeout(() => {
        cursor.classList.remove("expand");
    }, 500)
})